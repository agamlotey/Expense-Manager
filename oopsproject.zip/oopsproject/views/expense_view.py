class ExpenseView:
    def __init__(self, expenses):
        self.expenses = expenses

    def render_list(self):
        return "\n".join([e.display() for e in self.expenses]) or "No expenses."