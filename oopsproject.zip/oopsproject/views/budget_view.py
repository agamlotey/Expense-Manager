class BudgetView:
    def __init__(self, budgets):
        self.budgets = budgets

    def render_chart(self):
        # Simple text-based chart; UI will use Canvas for visual
        chart = "Budget Chart:\n"
        for b in self.budgets:
            bar = "#" * int((b.get_balance() / b.limit) * 10) if b.limit > 0 else ""
            chart += f"{b.category_id}: {bar} (${b.get_balance()})\n"
        return chart