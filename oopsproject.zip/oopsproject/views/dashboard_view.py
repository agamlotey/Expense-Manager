class DashboardView:
    def __init__(self, user, expenses, budgets):
        self.user = user
        self.expenses = expenses
        self.budgets = budgets

    def render_summary(self):
        total_expenses = sum(e.amount for e in self.expenses)
        over_budget = [b for b in self.budgets if b.is_over_budget()]
        return f"Dashboard for {self.user.display()}\nTotal Expenses: ${total_expenses}\nOver Budget: {len(over_budget)} categories"