from abc import ABC, abstractmethod

class Reportable(ABC):
    @abstractmethod
    def generate_report(self):
        pass

class ReportController(Reportable):
    def __init__(self, expense_ctrl, budget_ctrl):
        self.expense_ctrl = expense_ctrl
        self.budget_ctrl = budget_ctrl

    def generate_report(self):
        # Monthly report example
        total = sum(e.amount for e in self.expense_ctrl.expenses)
        return f"Monthly Report: Total Expenses ${total}"