from oopsproject.models.budget import Budget

class BudgetController:
    def __init__(self):
        self.budgets = []

    def add_budget(self, category_id, limit):
        budget = Budget(category_id, limit)
        self.budgets.append(budget)
        return budget

    def check_limits(self, category_id, amount):
        budget = next((b for b in self.budgets if b.category_id == category_id), None)
        if budget:
            budget.add_expense(amount)
            return budget.is_over_budget()
        return False