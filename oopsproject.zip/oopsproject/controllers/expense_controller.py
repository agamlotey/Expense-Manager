from oopsproject.models.expense import Expense

class ExpenseController:
    def __init__(self):
        self.expenses = []

    def add_expense(self, amount, description, date, category_id):
        expense = Expense(amount, description, date, category_id)
        self.expenses.append(expense)
        return expense

    def get_by_category(self, category_id):
        return [e for e in self.expenses if e.category_id == category_id]