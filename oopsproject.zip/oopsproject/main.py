# main.py
from tkinter import Tk
from ui.main_window import ExpenseApp

def main():
    root = Tk()
    app = ExpenseApp(root)
    root.mainloop()

if __name__ == '__main__':
    main()