import json
import os

class FileHandler:
    @staticmethod
    def save_to_file(filename, data):
        with open(filename, 'w') as f:
            json.dump([obj.__dict__ for obj in data], f, default=str)

    @staticmethod
    def load_from_file(filename):
        if os.path.exists(filename):
            with open(filename, 'r') as f:
                data = json.load(f)
                # Reconstruct objects (simplified; assumes Expense/Budget)
                return [type('Expense', (), d)() for d in data]  # Placeholder; customize per class
        return []