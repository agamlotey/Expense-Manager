from datetime import datetime, timedelta

class DateUtils:
    @staticmethod
    def format_date(date_str):
        return datetime.strptime(date_str, "%Y-%m-%d").date()

    @staticmethod
    def get_month_range(year, month):
        start = datetime(year, month, 1)
        end = start + timedelta(days=31)
        end = end.replace(day=1) - timedelta(days=1)
        return start.date(), end.date()