import tkinter as tk
from oopsproject.utils.validator import Validator

class ExpenseForm:
    def __init__(self, parent, expense_ctrl, budget_ctrl, callback):
        self.expense_ctrl = expense_ctrl
        self.budget_ctrl = budget_ctrl
        self.callback = callback
        self.window = tk.Toplevel(parent)
        self.window.title("Add Expense")
        self.setup_form()

    def setup_form(self):
        tk.Label(self.window, text="Amount:").grid(row=0, column=0)
        self.amount_entry = tk.Entry(self.window)
        self.amount_entry.grid(row=0, column=1)

        tk.Label(self.window, text="Description:").grid(row=1, column=0)
        self.desc_entry = tk.Entry(self.window)
        self.desc_entry.grid(row=1, column=1)

        tk.Label(self.window, text="Date (YYYY-MM-DD):").grid(row=2, column=0)
        self.date_entry = tk.Entry(self.window)
        self.date_entry.grid(row=2, column=1)

        tk.Label(self.window, text="Category ID:").grid(row=3, column=0)
        self.cat_entry = tk.Entry(self.window)
        self.cat_entry.grid(row=3, column=1)

        tk.Button(self.window, text="Add", command=self.add_expense).grid(row=4, columnspan=2)

    def add_expense(self):
        try:
            amount = float(self.amount_entry.get())
            if not Validator.validate_amount(amount):
                raise ValueError("Invalid amount")
            desc = self.desc_entry.get()
            date = self.date_entry.get()
            cat_id = self.cat_entry.get()
            expense = self.expense_ctrl.add_expense(amount, desc, date, cat_id)
            self.budget_ctrl.check_limits(cat_id, amount)
            self.callback()
            self.window.destroy()
        except ValueError as e:
            tk.messagebox.showerror("Error", str(e))