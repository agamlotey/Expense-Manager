# ui\main_window.py - Full interactive UI (writes safely in UTF-8)
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime
try:
    from models.user import User
    from models.category import Category
    from models.expense import Expense
    from models.budget import Budget
    from models.payment_method import PaymentMethod
    from models.transaction import Transaction
except Exception:
    # fallback placeholders if models can't be imported
    User = None
    Category = None
    Expense = None
    Budget = None
    PaymentMethod = None
    Transaction = None

class ExpenseApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        root.title('Expense Manager — DEVANSH SHARMA')
        root.geometry('980x640')
        try:
            root.configure(bg='#1f1f2e')
        except Exception:
            pass

        style = ttk.Style()
        try:
            style.theme_use('clam')
        except Exception:
            pass
        style.configure('TFrame', background='#1f1f2e')
        style.configure('TLabel', background='#1f1f2e', foreground='white', font=('Segoe UI', 10))
        style.configure('Header.TLabel', font=('Segoe UI', 14, 'bold'))
        style.configure('Accent.TButton', background='#ff69b4', foreground='white')
        style.configure('TButton', font=('Segoe UI', 10, 'bold'))

        # in-memory stores
        self.categories = []
        self.expenses = []
        self.budgets = []

        # header
        header = ttk.Frame(root, padding=(12,12))
        header.place(x=12, y=8, width=956, height=70)
        ttk.Label(header, text='Expense Management', style='Header.TLabel').pack(side='left', padx=(6,0))
        ttk.Label(header, text='  — DEV', foreground='#bbbbff').pack(side='left')

        # left: form
        left = ttk.Frame(root, padding=(10,10))
        left.place(x=12, y=88, width=360, height=520)
        ttk.Label(left, text='Add / Edit Expense', style='Header.TLabel').pack(anchor='w', pady=(0,8))

        form = ttk.Frame(left)
        form.pack(fill='x', pady=(4,8))

        ttk.Label(form, text='Description').grid(row=0, column=0, sticky='w')
        self.desc_var = tk.StringVar()
        ttk.Entry(form, textvariable=self.desc_var).grid(row=1, column=0, sticky='ew', pady=(2,8))

        ttk.Label(form, text='Amount').grid(row=2, column=0, sticky='w')
        self.amount_var = tk.StringVar()
        ttk.Entry(form, textvariable=self.amount_var).grid(row=3, column=0, sticky='ew', pady=(2,8))

        ttk.Label(form, text='Date (YYYY-MM-DD)').grid(row=4, column=0, sticky='w')
        self.date_var = tk.StringVar(value=datetime.now().strftime('%Y-%m-%d'))
        ttk.Entry(form, textvariable=self.date_var).grid(row=5, column=0, sticky='ew', pady=(2,8))

        ttk.Label(form, text='Category').grid(row=6, column=0, sticky='w')
        self.cat_combo = ttk.Combobox(form, values=[], state='readonly')
        self.cat_combo.grid(row=7, column=0, sticky='ew', pady=(2,8))

        ttk.Label(form, text='Payment Method').grid(row=8, column=0, sticky='w')
        self.pay_combo = ttk.Combobox(form, values=[], state='readonly')
        self.pay_combo.grid(row=9, column=0, sticky='ew', pady=(2,8))

        btn_frame = ttk.Frame(left)
        btn_frame.pack(fill='x', pady=(8,0))
        self.add_btn = ttk.Button(btn_frame, text='Add Expense', command=self.add_expense, style='Accent.TButton')
        self.add_btn.pack(side='left', padx=6, ipadx=6, ipady=6)
        self.clear_btn = ttk.Button(btn_frame, text='Clear', command=self.clear_form)
        self.clear_btn.pack(side='left', padx=6, ipadx=6, ipady=6)

        ttk.Separator(left, orient='horizontal').pack(fill='x', pady=12)
        ttk.Label(left, text='Categories & Budgets', style='Header.TLabel').pack(anchor='w', pady=(0,6))
        cb_frame = ttk.Frame(left)
        cb_frame.pack(fill='x', pady=(4,6))
        self.new_cat = tk.StringVar()
        ttk.Entry(cb_frame, textvariable=self.new_cat).grid(row=0, column=0, sticky='ew', padx=(0,6))
        self.new_limit = tk.StringVar(value='100')
        ttk.Entry(cb_frame, textvariable=self.new_limit, width=8).grid(row=0, column=1, sticky='e')
        ttk.Button(cb_frame, text='Add Category', command=self.add_category).grid(row=0, column=2, padx=(6,0))
        cb_frame.columnconfigure(0, weight=1)

        # right: list
        right = ttk.Frame(root, padding=(10,10))
        right.place(x=384, y=88, width=584, height=520)
        ttk.Label(right, text='Expenses', style='Header.TLabel').pack(anchor='w')

        cols = ('desc','amount','date','category','payment')
        self.tree = ttk.Treeview(right, columns=cols, show='headings', selectmode='browse', height=18)
        self.tree.heading('desc', text='Description')
        self.tree.heading('amount', text='Amount')
        self.tree.heading('date', text='Date')
        self.tree.heading('category', text='Category')
        self.tree.heading('payment', text='Payment')
        self.tree.column('desc', width=220)
        self.tree.column('amount', width=80, anchor='e')
        self.tree.column('date', width=90, anchor='center')
        self.tree.column('category', width=100)
        self.tree.column('payment', width=80)
        self.tree.pack(fill='both', expand=True, pady=(6,0))

        action_frame = ttk.Frame(right)
        action_frame.pack(fill='x', pady=(8,0))
        ttk.Button(action_frame, text='Edit Selected', command=self.edit_selected).pack(side='left', padx=6)
        ttk.Button(action_frame, text='Delete Selected', command=self.delete_selected).pack(side='left', padx=6)
        ttk.Button(action_frame, text='Export CSV', command=self.export_csv).pack(side='left', padx=6)

        summary = ttk.Frame(root)
        summary.place(x=12, y=610, width=956, height=18)
        self.status_label = ttk.Label(summary, text='Ready', anchor='w')
        self.status_label.pack(side='left', fill='x', expand=True)

        self.seed_defaults()
        self.refresh_ui()

    def seed_defaults(self):
        if not self.categories:
            if Category is not None:
                c1 = Category('Food','Food & Dining')
                c2 = Category('Transport','Commute & Travel')
            else:
                import uuid
                class P:
                    def __init__(self,name,desc):
                        self.id = str(uuid.uuid4())
                        self.name = name
                        self.description = desc
                c1 = P('Food','Food & Dining')
                c2 = P('Transport','Commute & Travel')
            self.categories.extend([c1, c2])
            if Budget is not None:
                self.budgets.append(Budget(c1.id, 300))
                self.budgets.append(Budget(c2.id, 150))
        if not hasattr(self, 'payment_methods') or not self.payment_methods:
            if PaymentMethod is not None:
                p1 = PaymentMethod('card','VISA **** 1234')
                p2 = PaymentMethod('cash','Cash')
                self.payment_methods = [p1,p2]
            else:
                import uuid
                class PM:
                    def __init__(self,t,d):
                        self.id = str(uuid.uuid4())
                        self.type = t
                        self.details = d
                self.payment_methods = [PM('card','VISA **** 1234'), PM('cash','Cash')]

    def refresh_ui(self):
        names = [c.name for c in self.categories]
        self.cat_combo['values'] = names
        self.pay_combo['values'] = [p.type for p in self.payment_methods]

        for row in self.tree.get_children():
            self.tree.delete(row)
        for e in self.expenses:
            cat_name = next((c.name for c in self.categories if getattr(c,'id',None) == getattr(e,'category_id',None)), 'N/A')
            pay_name = next((p.type for p in self.payment_methods if getattr(p,'id',None) == getattr(e,'payment_method_id',None)), 'N/A')
            try:
                amt = f"{e.amount:.2f}"
            except Exception:
                amt = str(getattr(e,'amount', '0'))
            self.tree.insert('', 'end', iid=getattr(e,'id', None) or str(len(self.tree.get_children())+1), values=(getattr(e,'description',''), amt, getattr(e,'date',''), cat_name, pay_name))

        self.status_label.config(text=f'{len(self.expenses)} expenses • {len(self.categories)} categories')

    def clear_form(self):
        self.desc_var.set('')
        self.amount_var.set('')
        self.date_var.set(datetime.now().strftime('%Y-%m-%d'))
        self.cat_combo.set('')
        self.pay_combo.set('')

    def add_category(self):
        name = self.new_cat.get().strip()
        try:
            limit = float(self.new_limit.get())
        except Exception:
            messagebox.showerror('Invalid limit','Budget limit must be a number')
            return
        if not name:
            messagebox.showerror('Invalid','Category name required')
            return
        if Category is not None:
            c = Category(name, '')
        else:
            import uuid
            class P:
                def __init__(self, name, desc):
                    self.id = str(uuid.uuid4())
                    self.name = name
                    self.description = desc
            c = P(name, '')
        self.categories.append(c)
        if Budget is not None:
            self.budgets.append(Budget(c.id, limit))
        self.new_cat.set('')
        self.refresh_ui()
        self.status_label.config(text=f'Added category: {name}')

    def add_expense(self):
        desc = self.desc_var.get().strip()
        try:
            amt = float(self.amount_var.get())
        except Exception:
            messagebox.showerror('Invalid amount','Enter a valid number for amount')
            return
        date = self.date_var.get().strip()
        cat_name = self.cat_combo.get()
        pay_name = self.pay_combo.get()
        if not (desc and cat_name and pay_name):
            messagebox.showerror('Missing fields','Description, category, and payment method are required')
            return
        cat = next((c for c in self.categories if c.name == cat_name), None)
        pay = next((p for p in self.payment_methods if p.type == pay_name), None)
        if not cat or not pay:
            messagebox.showerror('Invalid selection','Selected category or payment method not found')
            return
        if Expense is not None:
            e = Expense(amt, desc, date, cat.id)
        else:
            import uuid
            class E:
                def __init__(self, amount, description, date, category_id):
                    self.id = str(uuid.uuid4())
                    self.amount = amount
                    self.description = description
                    self.date = date
                    self.category_id = category_id
            e = E(amt, desc, date, cat.id)
        setattr(e, 'payment_method_id', getattr(pay,'id', None))
        self.expenses.append(e)
        b = next((bb for bb in self.budgets if getattr(bb,'category_id',None) == getattr(cat,'id',None)), None)
        if b:
            b.add_expense(amt)
        self.refresh_ui()
        self.clear_form()
        self.status_label.config(text=f'Added expense: {desc} • {amt:.2f}')

    def edit_selected(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showinfo('Edit', 'Select one expense to edit')
            return
        eid = sel[0]
        e = next((x for x in self.expenses if getattr(x,'id',None) == eid), None)
        if not e:
            messagebox.showerror('Not found','Expense not found')
            return
        self.desc_var.set(getattr(e,'description',''))
        self.amount_var.set(str(getattr(e,'amount','')))
        self.date_var.set(getattr(e,'date',''))
        cat_name = next((c.name for c in self.categories if getattr(c,'id',None) == getattr(e,'category_id',None)), '')
        self.cat_combo.set(cat_name)
        pay_name = next((p.type for p in self.payment_methods if getattr(p,'id',None) == getattr(e,'payment_method_id',None)), '')
        self.pay_combo.set(pay_name)
        self.expenses = [x for x in self.expenses if getattr(x,'id',None) != eid]
        b = next((bb for bb in self.budgets if getattr(bb,'category_id',None) == getattr(e,'category_id',None)), None)
        if b:
            b.add_expense(-getattr(e,'amount',0))
        self.refresh_ui()
        self.status_label.config(text=f'Editing: {getattr(e,"description","")}')

    def delete_selected(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showinfo('Delete', 'Select an expense to delete')
            return
        eid = sel[0]
        e = next((x for x in self.expenses if getattr(x,'id',None) == eid), None)
        if not e:
            messagebox.showerror('Not found','Expense not found')
            return
        if messagebox.askyesno('Confirm','Delete selected expense?'):
            self.expenses = [x for x in self.expenses if getattr(x,'id',None) != eid]
            b = next((bb for bb in self.budgets if getattr(bb,'category_id',None) == getattr(e,'category_id',None)), None)
            if b:
                b.add_expense(-getattr(e,'amount',0))
            self.refresh_ui()
            self.status_label.config(text=f'Deleted: {getattr(e,"description","")}')

    def export_csv(self):
        try:
            import csv, os
            fn = os.path.join('.', 'expenses_export.csv')
            with open(fn, 'w', newline='', encoding='utf-8') as f:
                w = csv.writer(f)
                w.writerow(['id','description','amount','date','category','payment'])
                for e in self.expenses:
                    cat_name = next((c.name for c in self.categories if getattr(c,'id',None) == getattr(e,'category_id',None)), 'N/A')
                    pay_name = next((p.type for p in self.payment_methods if getattr(p,'id',None) == getattr(e,'payment_method_id',None)), 'N/A')
                    w.writerow([getattr(e,'id',None), getattr(e,'description',None), getattr(e,'amount',None), getattr(e,'date',None), cat_name, pay_name])
            messagebox.showinfo('Export', f'Exported {len(self.expenses)} rows to {fn}')
        except Exception as ex:
            messagebox.showerror('Export error', str(ex))
