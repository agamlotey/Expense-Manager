# models/user.py
from .entity import Entity

class User(Entity):
    def __init__(self, name, email):
        super().__init__()
        self.name = name
        self.email = email

    def update_profile(self, name=None, email=None):
        if name:
            self.name = name
        if email:
            self.email = email

    def display(self):
        return f"User: {self.name} ({self.email})"