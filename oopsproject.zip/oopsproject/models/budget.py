# models/budget.py
from .entity import Entity

class Budget(Entity):
    def __init__(self, category_id, limit):
        super().__init__()
        self.category_id = category_id
        self.limit = limit
        self.__balance = limit  # Encapsulated

    def add_expense(self, amount):
        self.__balance -= amount

    def is_over_budget(self):
        return self.__balance < 0

    def get_balance(self):
        return self.__balance

    def display(self):
        return f"Budget for Category {self.category_id}: ${self.__balance} left of ${self.limit}"
