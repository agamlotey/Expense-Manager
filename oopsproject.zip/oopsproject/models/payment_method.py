# models/payment_method.py
from .entity import Entity

class PaymentMethod(Entity):
    def __init__(self, type_, details):
        super().__init__()
        self.type = type_
        self.details = details

    def validate(self):
        return bool(self.details)  # Basic validation

    def display(self):
        return f"Payment: {self.type} - {self.details}"
