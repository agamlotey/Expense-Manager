# models/category.py
from .entity import Entity

class Category(Entity):
    def __init__(self, name, description):
        super().__init__()
        self.name = name
        self.description = description

    def display(self):
        return f"Category: {self.name} - {self.description}"
