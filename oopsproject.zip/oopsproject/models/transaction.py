# models/transaction.py
from .entity import Entity

class Transaction(Entity):
    def __init__(self, expense_id, payment_method_id, status="pending"):
        super().__init__()
        self.expense_id = expense_id
        self.payment_method_id = payment_method_id
        self.status = status

    def process(self):
        self.status = "completed"

    def display(self):
        return f"Transaction: Expense {self.expense_id} via {self.payment_method_id} - {self.status}"
