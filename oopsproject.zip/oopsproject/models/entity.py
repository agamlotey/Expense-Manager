# models/entity.py
from abc import ABC, abstractmethod
import uuid
from datetime import datetime

class Entity(ABC):
    def __init__(self):
        self.id = str(uuid.uuid4())
        self.created_at = datetime.now()

    @abstractmethod
    def display(self):
        pass
