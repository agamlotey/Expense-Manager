# models/expense.py
from .entity import Entity

class Expense(Entity):
    def __init__(self, amount, description, date, category_id):
        super().__init__()
        self.amount = amount
        self.description = description
        self.date = date
        self.category_id = category_id

    def display(self):
        return f"Expense: {self.description} - ${self.amount} on {self.date}"